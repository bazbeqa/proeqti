from flask import Flask, render_template, request, redirect, url_for, session
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Word list
word_list = ['python', 'flask', 'hangman', 'game', 'programming']

@app.route('/')
def index():
    if 'word' not in session:
        session['word'] = random.choice(word_list)
        session['guesses'] = []
        session['incorrect'] = 0

    word = session['word']
    guesses = session['guesses']
    incorrect = session['incorrect']
    display_word = ''.join([letter if letter in guesses else '_' for letter in word])

    if '_' not in display_word:
        return render_template('result_hangman.html', word=word, result='You won!')
    elif incorrect >= 6:
        return render_template('result_hangman.html', word=word, result='You lost!')

    return render_template('hangman.html', word=display_word, incorrect=incorrect)

@app.route('/guess', methods=['POST'])
def guess():
    letter = request.form['letter'].lower()
    word = session['word']
    guesses = session['guesses']
    incorrect = session['incorrect']

    if letter not in guesses:
        guesses.append(letter)
        session['guesses'] = guesses

        if letter not in word:
            incorrect += 1
            session['incorrect'] = incorrect

    return redirect(url_for('index'))

@app.route('/reset')
def reset():
    session.pop('word', None)
    session.pop('guesses', None)
    session.pop('incorrect', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)