from flask import Flask, render_template, request

app = Flask(__name__)

choices = ['rock', 'paper', 'scissors']

@app.route('/')
def home():
    return render_template('index_RPS.html')

@app.route('/play', methods=['POST'])
def play():
    user_choice = request.form['choice'].lower()
    if user_choice not in choices:
        return "Invalid choice. Please choose rock, paper, or scissors."

    import random
    computer_choice = random.choice(choices)

    if user_choice == computer_choice:
        result = "It's a tie!"
    elif (user_choice == 'rock' and computer_choice == 'scissors') or \
         (user_choice == 'paper' and computer_choice == 'rock') or \
         (user_choice == 'scissors' and computer_choice == 'paper'):
        result = "You win!"
    else:
        result = "Computer wins!"

    return render_template('result_RPS.html', user_choice=user_choice, computer_choice=computer_choice, result=result)

if __name__ == '__main__':
    app.run(debug=True)